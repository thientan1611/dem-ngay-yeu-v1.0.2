<?php
define('License', ''); // Khóa giấy phép của bạn
